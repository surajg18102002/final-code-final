import azure.functions as func
import logging
import json

# Import helper modules from helpers package
from helpers.servicenow_helper import (
    fetch_incident_details,
    parse_incident_details,
    clean_for_snow,
    format_work_note_for_snow,
    update_incident_work_notes
)
from helpers.tidal_helper import fetch_job_output
from helpers.blob_storage_helper import load_knowledge_base, find_similar_tickets
from helpers.openai_helper import generate_incident_analysis, generate_incident_summary

app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)


# ============================================================
# HEALTH CHECK — for Azure container warmup
# ============================================================

@app.route(route="health", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def health_check(req: func.HttpRequest) -> func.HttpResponse:
    """Health check endpoint for Azure container warmup"""
    return func.HttpResponse(
        json.dumps({"status": "healthy", "message": "Function app is running"}),
        status_code=200,
        mimetype="application/json"
    )


# ============================================================
# ROUTE 1 — find similar tickets
# ============================================================

@app.route(route="find-similar-tickets", methods=["POST", "GET"])
def find_similar_tickets_http(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("find-similar-tickets triggered.")

    job_name = req.params.get("job_name", "")
    job_id = req.params.get("job_id", "")
    ticket_number = req.params.get("ticket_number", "")

    if not job_name:
        try:
            body = req.get_json()
            job_name = body.get("job_name", "").strip()
            job_id = body.get("job_id", "").strip()
            ticket_number = body.get("ticket_number", "").strip()
        except Exception:
            pass

    job_name = job_name.strip()
    job_id = job_id.strip()
    ticket_number = ticket_number.strip()

    if not job_name:
        return func.HttpResponse(
            json.dumps({"error": "job_name is required"}),
            status_code=400,
            mimetype="application/json"
        )

    config_item = job_name
    query_text = f"{job_name} {config_item} Completed Abnormally"

    try:
        df = load_knowledge_base()
        top_3 = find_similar_tickets(df, config_item, query_text, top_n=3)
    except Exception as e:
        logging.error(f"Search error: {e}")
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            status_code=500,
            mimetype="application/json"
        )

    return func.HttpResponse(
        json.dumps({
            "ticket_number": ticket_number,
            "job_name": job_name,
            "top_3_similar": top_3
        }, indent=2),
        status_code=200,
        mimetype="application/json"
    )


# ============================================================
# ROUTE 2 — full pipeline (with modularized helper functions)
# ============================================================

@app.route(route="process-incident", methods=["GET", "POST"])
def process_incident(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("process-incident triggered")

    # ── 1. Get incident number ────────────────────────────────────────────
    incident_number = (
        req.params.get("incident_number")
        or (req.get_json(silent=True) or {}).get("incident_number", "")
    )
    incident_number = incident_number.strip().upper()
    if not incident_number:
        return func.HttpResponse(
            json.dumps({"error": "incident_number is required"}),
            status_code=400,
            mimetype="application/json"
        )
    if not incident_number.startswith("INC"):
        incident_number = "INC" + incident_number

    pipeline = {"incident_number": incident_number, "steps": {}}

    # ── 2. Fetch ServiceNow ───────────────────────────────────────────────
    try:
        snow_data = fetch_incident_details(incident_number)
        pipeline["steps"]["servicenow_fetch"] = "success"
    except Exception as e:
        pipeline["steps"]["servicenow_fetch"] = f"FAILED: {e}"
        return func.HttpResponse(
            json.dumps(pipeline),
            status_code=500,
            mimetype="application/json"
        )

    # Parse incident details
    parsed_details = parse_incident_details(snow_data)
    short_desc = parsed_details["short_desc"]
    config_item = parsed_details["config_item"]
    work_notes = parsed_details["work_notes"]
    assignment_group = parsed_details["assignment_group"]
    job_name = parsed_details["job_name"]
    job_id = parsed_details["job_id"]

    pipeline["parsed"] = {
        "job_name": job_name,
        "job_id": job_id,
        "short_desc": short_desc,
        "config_item": config_item
    }

    # ── 3. Fetch Tidal log ────────────────────────────────────────────────
    if job_id:
        try:
            tidal_output, tidal_debug_info = fetch_job_output(job_id)
            pipeline["steps"]["tidal_fetch"] = "success"
            pipeline["tidal_debug"] = tidal_debug_info
        except Exception as e:
            tidal_output = f"Tidal fetch failed: {e}"
            pipeline["steps"]["tidal_fetch"] = f"FAILED: {e}"
            pipeline["tidal_debug"] = {"error": str(e)}
    else:
        tidal_output = ""
        pipeline["steps"]["tidal_fetch"] = "skipped — no job_id parsed"
        pipeline["tidal_debug"] = {"reason": "no job_id parsed from short description"}

    # ── 4. Similarity search ──────────────────────────────────────────────
    try:
        df = load_knowledge_base()
        error_snippet = tidal_output[:1000] if tidal_output and 'failed' not in tidal_output.lower() else ''
        query_text = f"{job_name} {config_item} Completed Abnormally {short_desc} {error_snippet}"
        top_3 = find_similar_tickets(df, job_name, query_text, top_n=3)
        pipeline["steps"]["similarity_search"] = "success"
        logging.info(f"Found {len(top_3)} similar tickets for {job_name}")
    except Exception as e:
        top_3 = []
        pipeline["steps"]["similarity_search"] = f"FAILED: {e}"
        logging.error(f"Similarity search failed: {e}")

    # ── 4b. Generate AI summaries for similar incidents ──────────────────
    if top_3:
        try:
            logging.info(f"Generating AI summaries for {len(top_3)} similar incidents")
            for ticket in top_3:
                try:
                    ai_summary = generate_incident_summary(
                        ticket_number=ticket['ticket_number'],
                        config_item=ticket['config_item'],
                        short_description=ticket.get('short_description', ''),
                        work_notes=ticket.get('work_notes', ''),
                        resolution_notes=ticket.get('resolution_notes', '')
                    )
                    ticket['ai_summary'] = ai_summary
                    logging.info(f"Generated summary for {ticket['ticket_number']}: {ai_summary[:100]}...")
                except Exception as summary_error:
                    logging.warning(f"Failed to generate summary for {ticket['ticket_number']}: {summary_error}")
                    ticket['ai_summary'] = "Summary generation failed."
            pipeline["steps"]["ai_summaries"] = "success"
        except Exception as e:
            logging.error(f"AI summary generation error: {e}")
            pipeline["steps"]["ai_summaries"] = f"FAILED: {e}"

    # ── 5. GPT analysis ───────────────────────────────────────────────────
    try:
        logging.info(f"Starting GPT analysis for incident {incident_number}")
        logging.info(f"Similar tickets found: {len(top_3)}")
        final_report = generate_incident_analysis(
            incident_number=incident_number,
            short_desc=short_desc,
            assignment_group=assignment_group,
            config_item=config_item,
            job_name=job_name,
            job_id=job_id,
            tidal_output=tidal_output,
            similar_incidents=top_3
        )
        logging.info(f"GPT analysis completed. Report length: {len(final_report) if final_report else 0}")
        pipeline["steps"]["gpt_analysis"] = "success"
        pipeline["gpt_report_length"] = len(final_report) if final_report else 0
    except Exception as e:
        final_report = f"GPT analysis failed: {e}"
        pipeline["steps"]["gpt_analysis"] = f"FAILED: {e}"
        logging.error(f"GPT error: {e}")
        import traceback
        logging.error(traceback.format_exc())

    # ── 6. Update ServiceNow ──────────────────────────────────────────────
    clean_report = clean_for_snow(final_report)
    
    # Validate report before attempting ServiceNow update
    if not clean_report or len(clean_report.strip()) < 10:
        logging.warning(f"Skipping ServiceNow update - report is empty or too short (length: {len(clean_report) if clean_report else 0})")
        pipeline["steps"]["servicenow_update"] = "SKIPPED: Empty or invalid report content"
        pipeline["snow_update_response"] = {
            "error": "Report content was empty or too short to update ServiceNow",
            "report_length": len(clean_report) if clean_report else 0,
            "reason": "GPT analysis may have failed or returned empty response"
        }
    else:
        try:
            snow_update_response = update_incident_work_notes(incident_number, clean_report)
            pipeline["steps"]["servicenow_update"] = "success"
            pipeline["snow_update_response"] = snow_update_response
        except Exception as e:
            pipeline["steps"]["servicenow_update"] = f"FAILED: {e}"
            pipeline["snow_update_response"] = {"error": str(e)}
            logging.error(f"ServiceNow update error: {e}")

    # ── 7. Return ─────────────────────────────────────────────────────────
    pipeline["final_report"] = final_report
    pipeline["final_report_length"] = len(final_report) if final_report else 0
    pipeline["top_3_similar"] = top_3
    pipeline["tidal_raw"] = tidal_output[:2000]
    pipeline["tidal_length"] = len(tidal_output)

    return func.HttpResponse(
        json.dumps(pipeline, indent=2),
        status_code=200,
        mimetype="application/json"
    )

