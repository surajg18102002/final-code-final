# GitHub Workflows

This directory contains GitHub Actions workflows used for automating various tasks in this repository. Below is a brief description of each workflow file:

## Workflows

### [sample_ci.yml](sample_ci.yml)
This workflow is a sample Continuous Integration (CI) pipeline that follows the DevOps team standards. It can be used as a guideline to create your own CI workflows based on your source code.

### [story_linking_check.yml](story_linking_check.yml)
This workflow ensures that pull requests are linked to work items in Azure DevOps. It includes the following steps:
- **Generate Description**: Updates the pull request description with additional information.
- **Story Link Validity Check**: Verifies if the pull request is linked to a work item.

## Next Steps
1. Customize the `sample_ci.yml` to fit your project's CI requirements.
2. The `story_linking_check.yml` is configured to link pull requests to Azure DevOps work items.
3. Modify the workflows as needed to meet your project's specific needs.

For more information on GitHub Actions, refer to the [official documentation](https://docs.github.com/en/actions).
DevOps Reusable actions can be found here :https://github.com/orgs/CareSourceIT/repositories?q=csact
DevOps Reusable workflows can be found here: https://github.com/orgs/CareSourceIT/repositories?q=csrw
DevOps Github Standards can be found here: https://wiki.caresource.corp/wiki/Category:GitHub