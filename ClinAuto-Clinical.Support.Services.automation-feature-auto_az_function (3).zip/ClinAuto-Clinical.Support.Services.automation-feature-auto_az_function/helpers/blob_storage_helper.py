"""
Blob Storage Helper Module
Handles Azure Blob Storage operations for knowledge base management and similarity search.
"""

import logging
import os
import io
import re
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from azure.storage.blob import BlobServiceClient


# Blob Storage Configuration
BLOB_CONNECTION_STRING = os.environ.get("BLOB_CONNECTION_STRING", "")
BLOB_CONTAINER_NAME = os.environ.get("BLOB_CONTAINER_NAME", "")
BLOB_FILE_NAME = os.environ.get("BLOB_FILE_NAME", "")

# Global cache for knowledge base
_df_cache = None


def load_knowledge_base() -> pd.DataFrame:
    """
    Load knowledge base from Azure Blob Storage.
    Uses global caching to avoid repeated downloads.
    
    Returns:
        pd.DataFrame: Knowledge base dataframe with processed search text
    """
    global _df_cache
    
    if _df_cache is not None:
        logging.info("Using cached knowledge base.")
        return _df_cache

    logging.info("Loading knowledge base from blob storage...")

    blob_service = BlobServiceClient.from_connection_string(BLOB_CONNECTION_STRING)
    blob_client = blob_service.get_blob_client(container=BLOB_CONTAINER_NAME, blob=BLOB_FILE_NAME)
    blob_data = blob_client.download_blob().readall()

    # Try to read CSV with different encodings
    try:
        df = pd.read_csv(io.BytesIO(blob_data), encoding='utf-8')
    except UnicodeDecodeError:
        logging.warning("UTF-8 failed, trying latin-1 encoding")
        df = pd.read_csv(io.BytesIO(blob_data), encoding='latin-1')

    # Standardize column names
    df.columns = df.columns.str.strip()
    
    # Build rename map for columns that exist
    rename_map = {}
    if 'Number' in df.columns:
        rename_map['Number'] = 'number'
    if 'Configuration item' in df.columns:
        rename_map['Configuration item'] = 'config_item'
    if 'Work notes' in df.columns:
        rename_map['Work notes'] = 'work_notes'
    if 'Resolution notes' in df.columns:
        rename_map['Resolution notes'] = 'resolution_notes'
    if 'Short description' in df.columns:
        rename_map['Short description'] = 'short_description'
    if 'Description' in df.columns:
        rename_map['Description'] = 'description'
    
    df = df.rename(columns=rename_map)
    
    # Ensure required columns exist
    if 'work_notes' not in df.columns:
        df['work_notes'] = ''
    if 'resolution_notes' not in df.columns:
        df['resolution_notes'] = ''
    if 'config_item' not in df.columns:
        df['config_item'] = ''
    if 'short_description' not in df.columns:
        df['short_description'] = ''
    if 'description' not in df.columns:
        df['description'] = ''
    
    # Fill NA values
    df['work_notes'] = df['work_notes'].fillna('')
    df['resolution_notes'] = df['resolution_notes'].fillna('')
    df['config_item'] = df['config_item'].fillna('')
    df['short_description'] = df['short_description'].fillna('')
    df['description'] = df['description'].fillna('')

    # Build search text for each record
    df['search_text'] = df.apply(
        lambda r: build_search_text(
            r['work_notes'], 
            r['resolution_notes'], 
            r['config_item'],
            r.get('short_description', ''),
            r.get('description', '')
        ),
        axis=1
    )
    df = df[df['search_text'].str.strip() != ''].reset_index(drop=True)

    _df_cache = df
    logging.info(f"Loaded {len(df)} records, {df['config_item'].nunique()} config items.")
    return df


def build_search_text(work_notes: str, resolution_notes: str, config_item: str, 
                     short_description: str = '', description: str = '') -> str:
    """
    Build searchable text with weighted importance.
    
    Args:
        work_notes: Work notes from incident
        resolution_notes: Resolution notes from incident
        config_item: Configuration item name
        short_description: Short description of incident
        description: Detailed description of incident
        
    Returns:
        str: Weighted search text for similarity matching
    """
    def clean_text(text: str) -> str:
        """Remove timestamps, boilerplate, and incident numbers."""
        text = re.sub(r'\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2} [AP]M - .+?\(Work notes\)', ' ', text)
        text = re.sub(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}', ' ', text)
        text = re.sub(r'\b[A-Z]{3}\d{7,}\b', ' ', text)
        # Replace pipe characters with spaces to avoid tokenization issues
        text = text.replace('|', ' ')
        
        for phrase in [
            'Task auto-reassigned to Managed Services team',
            'Work notes from INCTASK',
            'Please investigate',
            'Job Output can be found in Tidal',
            'Please see work notes for parent group and agent information',
            'Additional comments:',
            'Work in progress',
            'PRD Tidal Job',
        ]:
            text = text.replace(phrase, ' ')
        
        text = re.sub(r'\s+', ' ', text).strip()
        return text
    
    short_desc_clean = clean_text(short_description) if short_description else ''
    desc_clean = clean_text(description) if description else ''
    work_clean = clean_text(work_notes)
    resolution_clean = clean_text(resolution_notes)
    config_clean = config_item.strip()
    
    # Weighted text: short_description (3x), description (2x), config (2x), notes (1x)
    weighted_text = f"{short_desc_clean} {short_desc_clean} {short_desc_clean} "
    weighted_text += f"{desc_clean} {desc_clean} "
    weighted_text += f"{config_clean} {config_clean} "
    weighted_text += f"{work_clean} {resolution_clean}"
    
    weighted_text = re.sub(r'\s+', ' ', weighted_text).strip()
    
    return weighted_text


def expand_query(query_text: str) -> str:
    """
    Expand query with common error term synonyms and patterns for better matching.
    
    Args:
        query_text: Original query text
        
    Returns:
        str: Expanded query with synonyms
    """
    expansions = {
        'fail': ['failed', 'failure', 'error', 'unsuccessful', 'abort', 'terminated'],
        'error': ['fail', 'exception', 'issue', 'problem', 'fault', 'critical'],
        'disk': ['storage', 'space', 'volume', 'filesystem', 'partition', 'full'],
        'memory': ['ram', 'heap', 'oom', 'out of memory', 'allocation'],
        'timeout': ['timed out', 'connection lost', 'hung', 'unresponsive', 'stuck'],
        'permission': ['access denied', 'unauthorized', 'forbidden', 'privilege'],
        'database': ['db', 'sql', 'oracle', 'connection', 'query', 'deadlock'],
        'network': ['connection', 'connectivity', 'socket', 'port', 'firewall', 'unreachable'],
        'abnormal': ['abnormally', 'unexpected', 'irregular', 'anomalous'],
        'completed': ['finished', 'ended', 'terminated', 'done'],
        'job': ['task', 'process', 'batch', 'script', 'workflow'],
        'restart': ['restarted', 'rebooted', 'recycled', 'bounced'],
        'file': ['files', 'document', 'data', 'archive'],
    }
    
    expanded = query_text.lower()
    for key, synonyms in expansions.items():
        if key in expanded:
            for synonym in synonyms:
                if synonym not in expanded:
                    expanded += ' ' + synonym
    
    return expanded


def extract_resolution_action(work_notes: str, resolution_notes: str, 
                             short_description: str = '', description: str = '') -> str:
    """
    Extract and format resolution action from incident notes.
    Prioritizes actual resolution over boilerplate text.
    
    Args:
        work_notes: Work notes from incident
        resolution_notes: Resolution notes from incident
        short_description: Short description of incident
        description: Detailed description of incident
        
    Returns:
        str: Formatted resolution action text
    """
    # Clean resolution notes (priority source)
    resolution_clean = str(resolution_notes).strip()
    resolution_clean = re.sub(r'\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2} [AP]M - .+?\(Work notes\)', '\n', resolution_clean)
    
    # Clean work notes
    work_clean = str(work_notes).strip()
    work_clean = re.sub(r'\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2} [AP]M - .+?\(Work notes\)', '\n', work_clean)
    
    # Remove boilerplate phrases from both
    boilerplate = [
        'Task auto-reassigned to Managed Services team',
        'Work notes from INCTASK',
        'Please investigate',
        'Job Output can be found in Tidal',
        'Please see work notes for parent group and agent information',
        'Additional comments:',
        'Work in progress',
    ]
    
    for phrase in boilerplate:
        resolution_clean = resolution_clean.replace(phrase, '')
        work_clean = work_clean.replace(phrase, '')
    
    # Remove generic Parent/Agent lines (not actual resolutions)
    resolution_clean = re.sub(r'Parent:\\[^|]+\|\s*Agent:\s*\S+', '', resolution_clean)
    work_clean = re.sub(r'Parent:\\[^|]+\|\s*Agent:\s*\S+', '', work_clean)
    
    # Clean up whitespace
    resolution_clean = re.sub(r'\n+', ' ', resolution_clean)
    resolution_clean = re.sub(r'\s+', ' ', resolution_clean).strip()
    work_clean = re.sub(r'\n+', ' ', work_clean)
    work_clean = re.sub(r'\s+', ' ', work_clean).strip()
    
    # Build result - prioritize resolution notes if meaningful
    if resolution_clean and len(resolution_clean) > 30:
        return f"Resolution: {resolution_clean[:500]}"
    elif work_clean and len(work_clean) > 30:
        return f"Notes: {work_clean[:500]}"
    elif short_description and len(short_description.strip()) > 10:
        return f"Issue: {short_description.strip()[:300]}"
    else:
        return 'No meaningful resolution details available'


def find_similar_tickets(df: pd.DataFrame, config_item: str, query_text: str, top_n: int = 3) -> list:
    """
    Enhanced similarity search with multi-stage filtering and better relevance scoring.
    Strictly prioritizes exact job name matches.
    
    Args:
        df: Knowledge base DataFrame
        config_item: Configuration item to match (job name)
        query_text: Query text for similarity search
        top_n: Number of top results to return
        
    Returns:
        list: List of similar tickets with ticket_number, config_item, resolution_action, 
              similarity_score, and relevance_score
    """
    # Stage 1: STRICT exact config_item match (exact job name only)
    exact_match = df[df['config_item'].str.strip() == config_item.strip()].copy()
    logging.info(f"Stage 1 [Exact match for {config_item}]: {len(exact_match)} tickets")
    
    # Stage 2: Only use exact matches - do NOT return unrelated jobs
    if len(exact_match) >= 3:
        # We have enough exact matches - use only these
        filtered = exact_match
        logging.info(f"Using {len(filtered)} exact matches for {config_item}")
    elif len(exact_match) > 0:
        # We have some exact matches - use only these even if < 3
        filtered = exact_match
        logging.info(f"Using {len(filtered)} exact matches (less than requested) for {config_item}")
    else:
        # No exact matches found - return empty results instead of wrong data
        logging.warning(f"No exact matches found for job name '{config_item}' - returning empty results to avoid wrong data")
        return []
    
    if len(filtered) == 0:
        return []
    
    # Expand query with synonyms
    expanded_query = expand_query(query_text)
    corpus = filtered['search_text'].tolist()
    corpus_with_query = corpus + [expanded_query]
    
    try:
        # Enhanced TF-IDF parameters
        vectorizer = TfidfVectorizer(
            stop_words='english',
            ngram_range=(1, 3),
            min_df=1,
            max_df=1.0,  # Allow terms that appear in all documents (was 0.85)
            max_features=10000,
            sublinear_tf=True,
            norm='l2',
            use_idf=True
        )
        tfidf_matrix = vectorizer.fit_transform(corpus_with_query)
    except Exception as e:
        logging.error(f"TF-IDF error: {e}")
        return []
    
    query_vector = tfidf_matrix[-1]
    corpus_matrix = tfidf_matrix[:-1]
    similarities = cosine_similarity(query_vector, corpus_matrix).flatten()
    
    filtered = filtered.copy()
    filtered['similarity'] = similarities
    
    # Multi-factor relevance scoring
    error_keywords = ['error', 'fail', 'exception', 'timeout', 'denied', 'disk', 'memory', 
                      'abnormal', 'abort', 'terminated', 'critical', 'fatal', 'oom']
    
    def calculate_relevance_score(row):
        """Calculate enhanced relevance score with multiple factors."""
        base_score = row['similarity']
        
        # STRONG boost for exact config match (50%) - ensures exact job name matches rank higher
        config_boost = 0.5 if row['config_item'].strip() == config_item.strip() else 0
        
        # Boost for error keyword matches in short_description (10% per keyword, max 30%)
        short_desc = row.get('short_description', '').lower()
        query_lower = query_text.lower()
        
        short_desc_boost = sum(0.1 for keyword in error_keywords 
                              if keyword in short_desc and keyword in query_lower)
        short_desc_boost = min(short_desc_boost, 0.3)
        
        # Boost for error keyword matches in general text (5% per keyword, max 15%)
        text_lower = row['search_text'].lower()
        text_boost = sum(0.05 for keyword in error_keywords 
                        if keyword in text_lower and keyword in query_lower)
        text_boost = min(text_boost, 0.15)
        
        return base_score * (1 + config_boost + short_desc_boost + text_boost)
    
    filtered['relevance_score'] = filtered.apply(calculate_relevance_score, axis=1)
    
    # Filter out very low scores
    filtered = filtered[filtered['relevance_score'] > 0.01]
    top_results = filtered.sort_values('relevance_score', ascending=False).head(top_n * 2)
    
    # Quality filtering
    if len(top_results) > top_n:
        top_score = top_results.iloc[0]['relevance_score']
        quality_threshold = top_score * 0.3
        top_results = top_results[top_results['relevance_score'] >= quality_threshold].head(top_n)
    
    # Format results
    results = []
    for _, row in top_results.iterrows():
        results.append({
            "ticket_number": row['number'],
            "config_item": row['config_item'],
            "short_description": row.get('short_description', ''),
            "work_notes": row.get('work_notes', ''),
            "resolution_notes": row.get('resolution_notes', ''),
            "resolution_action": extract_resolution_action(
                row['work_notes'], 
                row['resolution_notes'],
                row.get('short_description', ''),
                row.get('description', '')
            )[:1000],
            "resolution_details": extract_resolution_action(
                row['work_notes'], 
                row['resolution_notes'],
                row.get('short_description', ''),
                row.get('description', '')
            )[:500],
            "similarity_score": round(float(row['similarity']), 4),
            "relevance_score": round(float(row['relevance_score']), 4)
        })
    
    avg_relevance = sum(r['relevance_score'] for r in results) / len(results) if results else 0
    logging.info(f"Returning {len(results)} tickets with avg relevance: {avg_relevance:.4f}")
    
    return results
