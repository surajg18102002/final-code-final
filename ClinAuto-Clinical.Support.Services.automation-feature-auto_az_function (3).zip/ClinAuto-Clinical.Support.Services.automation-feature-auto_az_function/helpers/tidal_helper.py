"""
Tidal Helper Module
Handles all Tidal API operations including authentication and job output retrieval.
"""

import logging
import os
import base64
import requests
import xml.etree.ElementTree as ET


# Tidal API Configuration
TIDAL_URL = os.environ.get("TIDAL_BASE_URL", "https://crt-apim.caresource.corp/TidalAutomation/")
TIDAL_USERNAME = os.environ.get("TIDAL_USERNAME", "")
TIDAL_PASSWORD = os.environ.get("TIDAL_PASSWORD", "")
TIDAL_API_KEY = os.environ.get("TIDAL_API_KEY", "")


def get_tidal_headers() -> dict:
    """
    Generate Tidal API authentication headers with Basic authentication.
    
    Returns:
        dict: Headers dictionary with Authorization, API key, and Content-Type
    """
    credentials = f"{TIDAL_USERNAME}:{TIDAL_PASSWORD}"
    auth_string = base64.b64encode(credentials.encode()).decode()
    
    return {
        "User-Agent": "CareSource-TidalJobs/1.2",
        "Authorization": f"Basic {auth_string}",
        "x-api-key": TIDAL_API_KEY,
        "Content-Type": "application/x-www-form-urlencoded"
    }


def fetch_job_output(job_id: str) -> tuple[str, dict]:
    """
    Fetch Tidal job output for a specific job run ID.
    
    Args:
        job_id: The Tidal job run ID
        
    Returns:
        tuple: (job_output: str, debug_info: dict)
            - job_output: The extracted job output text
            - debug_info: Debug information about the request
    """
    tidal_output = ""
    debug_info = {}
    
    if not job_id:
        debug_info = {"reason": "no job_id provided"}
        return "", debug_info
    
    try:
        # Construct the XML payload to fetch job output
        xml_payload = (
            '<?xml version="1.0" encoding="UTF-8" ?>\n'
            '<entry xmlns="http://purl.org/atom/ns#">\n'
            '\t<tes:JobOutput.getJobOutputRaw xmlns:tes="http://www.tidalsoftware.com/client/tesservlet">\n'
            f'\t\t<id>{job_id}</id>\n'
            '\t</tes:JobOutput.getJobOutputRaw>\n'
            '</entry>'
        )
        
        logging.info(f"Fetching Tidal log for job_id: {job_id}")
        
        tidal_resp = requests.post(
            TIDAL_URL,
            headers=get_tidal_headers(),
            data={"data": xml_payload},
            timeout=60,
            verify=False
        )
        
        # Store debug information
        debug_info = {
            "status_code": tidal_resp.status_code,
            "response_length": len(tidal_resp.text),
            "job_id_used": job_id
        }
        
        tidal_resp.raise_for_status()
        raw_response = tidal_resp.text
        
        # Parse the XML response to extract the actual job output
        tidal_output = _parse_tidal_response(raw_response, job_id)
        
        debug_info["output_length"] = len(tidal_output)
        logging.info(f"Successfully fetched Tidal output: {len(tidal_output)} chars")
        
    except Exception as e:
        tidal_output = f"Tidal fetch failed: {e}"
        debug_info["error"] = str(e)
        logging.error(f"Tidal fetch error for job_id {job_id}: {e}")
    
    return tidal_output, debug_info


def _parse_tidal_response(raw_response: str, job_id: str) -> str:
    """
    Parse XML response from Tidal to extract job output.
    
    The response structure is: <entry><xs:string>ACTUAL_OUTPUT</xs:string></entry>
    
    Args:
        raw_response: Raw XML response from Tidal API
        job_id: Job ID (for logging purposes)
        
    Returns:
        str: Extracted job output or error message
    """
    try:
        root = ET.fromstring(raw_response)
        
        # Try direct text content
        if root.text and root.text.strip():
            logging.info(f"Extracted tidal output from root.text: {len(root.text)} chars")
            return root.text.strip()
        
        # Try finding xs:string or string elements with namespaces
        namespaces = {
            'xs': 'http://www.w3.org/2001/XMLSchema',
            'atom': 'http://purl.org/atom/ns#'
        }
        
        # Try with namespace
        string_elem = root.find('.//xs:string', namespaces)
        if string_elem is not None and string_elem.text:
            logging.info(f"Extracted from xs:string element: {len(string_elem.text)} chars")
            return string_elem.text.strip()
        
        # Try without namespace
        for elem in root.iter():
            if elem.tag.endswith('string') and elem.text and elem.text.strip():
                logging.info(f"Extracted from {elem.tag}: {len(elem.text)} chars")
                return elem.text.strip()
        
        # If still empty, return error message with raw XML sample
        logging.warning(f"Empty Tidal output for job_id {job_id}. Raw: {raw_response[:500]}")
        return f"Empty job output returned. Raw response: {raw_response}"
        
    except ET.ParseError as parse_err:
        # If XML parsing fails, use the raw text
        logging.warning(f"XML parse error, using raw response: {parse_err}")
        return raw_response
